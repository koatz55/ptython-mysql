from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.user import User

@app.route('/')
def home():
    return redirect('/all_users')

@app.route('/create')
def newuser():
    return render_template('index.html')

@app.route('/add_user', methods=["POST"])
def create_user():
    if not User.validate_pirate(request.form):
        return redirect('/create')
    data = {
    'first_name': request.form['first_name'],
    "last_name" : request.form["last_name"], 
    "email" : request.form["email"]}
    User.save(data)
    return redirect('/all_users')

@app.route("/all_users")
def index():
    users = User.get_all()
    print(users)
    return render_template("all_crew.html", all_users = users)

@app.route("/user/edit/<int:id>")
def edit(id):
    data = {
        'id' : id,
    }
    return render_template("edit_user.html", user = User.get_one(data))

@app.route("/user/update/<int:id>", methods=["POST"])
def update(id):
    if not User.validate_pirate(request.form):
        data = {
        'id' : id,
        'first_name': request.form['first_name'],
        "last_name" : request.form["last_name"], 
        "email" : request.form["email"]}
        return render_template("edit_user.html", user = User.get_one(data))
    data = {
    'id' : id,
    'first_name': request.form['first_name'],
    "last_name" : request.form["last_name"], 
    "email" : request.form["email"]}
    User.update(data)
    print("updated")
    return redirect("/all_users")

@app.route('/user/destroy/<int:id>')
def destroy(id):
    data ={
        'id': id
    }
    User.destroy(data)
    return redirect('/')

@app.route("/user/view/<int:id>")
def view(id):
    data = {
        "id" : id
    }
    return render_template('pirateinfo.html', user = User.get_one(data))